package com.example.b20210305044;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.a20210305044.R;

public class CarList2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_list2);

        Button kiralabutton = (Button) findViewById(R.id.kiralamabutonu);
        Button btn = (Button) findViewById(R.id.button);
        Button kiralabutton2 = findViewById(R.id.kiralamabutonu2);
        Button kiralabuton3 = findViewById(R.id.kiralamabutonu3);
        kiralabuton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent corsarent = new Intent(CarList2.this, com.example.b20210305044.corsarent.class);
                startActivity(corsarent);
            }
        });
        kiralabutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i20rent = new Intent(CarList2.this, com.example.b20210305044.i20rent.class);
                startActivity(i20rent);
            }
        });

        kiralabutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cliorent = new Intent(CarList2.this, cliorent2.class);
                startActivity(cliorent);

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CarList2.this, MainActivity.class);
                startActivity(intent);

                ImageView imageViewCar = findViewById(R.id.imageView1);
                imageViewCar.setImageResource(R.drawable.clioblack);

                ImageView imageViewCar2 = findViewById(R.id.imageView3);
                imageViewCar2.setImageResource(R.drawable.i20white);

                ImageView imageViewCar3 = findViewById(R.id.imageView4);
                imageViewCar3.setImageResource(R.drawable.opelcorsa);

                    }
                });
            }


        }

